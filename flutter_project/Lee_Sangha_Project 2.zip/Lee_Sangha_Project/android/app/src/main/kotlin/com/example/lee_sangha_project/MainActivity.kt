package com.example.lee_sangha_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
